﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CcrLogAnalyzer.Models.Dao
{
    public interface ITDao
    {
        int Id { get; set; }
    }
}
