﻿using CcrLogAnalyzer.Factories;
using CcrLogAnalyzer.Models;
using CcrLogAnalyzer.ViewModels.Appsettings;
using MVVM.Generic.Commands;
using MVVM.Generic.Services;
using MVVM.Generic.VM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;

namespace CcrLogAnalyzer.ViewModels.Main
{
    // --------------------
    // MODELO DE LÍNEAS DE LOS EVENTOS
    // --------------------
    public class LogFileEventInfo
    {
        public string NameLog { get; set; }
        public string FilePath { get; set; }
        public int EventCount { get; set; }
        public string LineContent { get; set; }
        public string EventType { get; set; }
        public bool IsVisible { get; set; } = true;
    }

    // -----------------------
    // VIEWMODEL PRINCIPAL
    // -----------------------
    public class MainVM : BaseViewModel
    {
        // ------------------
        // CAMPOS PRIVADOS
        // ------------------
        private readonly IFileExplorerDialog _fileExplorerDialog;
        private ICommand _browseCommand;

        private string _browsePath;
        private string _selectedOption;
        private string _selectedEvent;
        private LogFileEventInfo _selectedLog;
        private string _filePreviewContent;
        private ConfigEntry _selectedConfig;

        // Expresiones Regex
        private readonly Regex _eventPattern =
            new(@"(ERROR|EVENT|WARN|REMOTE|LOCAL|TIME|0/0/0)", RegexOptions.IgnoreCase);

        private readonly Regex _timeRegex =
            new(@"^\d+/\d+/\d+\s+(\d+:\d+:\d+:\d+)", RegexOptions.Compiled);

        private readonly List<string> _deepEvent = new()
        {
            "Previous Local", "Power Loss", "STEP", "Sensor", "REMOTE",
            "Save config", "CCR", "Voltage", "Temperature",
            "HoroMeter", "Hours", "Minutes", "Time", "Redundancy", "Startup", "LFD", "JBUS",
            "Number", "CTS", "Communication"
        };

        private const string SettingsFile = "settings.json";

        // -------------------
        // PROPIEDADES DE UI
        // -------------------
        // Lista mostrada en el DataGrid
        public ObservableCollection<LogFileEventInfo> LogFileEventCounts { get; set; } = new();
        public ObservableCollection<string> ComboOptions { get; }
        public ObservableCollection<string> DistinctEvents { get; set; } = new();
        public ObservableCollection<ConfigEntry> ConfigHistory { get; set; } = new();

        public ICollectionView FilteredEventsView { get; set; }

        // BrowserPath Setter y Getter
        public string BrowsePath
        {
            get => _browsePath;
            set
            {
                if (_browsePath == value)
                    return;

                _browsePath = value;
                RaisePropertyChanged();

                _ = AutoLoadAsync();
            }
        }

        // Campos para el filtro por tiempo
        public string StartTime { get; set; } = "0:0:0:000";
        public string EndTime { get; set; } = "0:0:10:000";

        public string SelectedOption
        {
            get => _selectedOption;
            set
            {
                _selectedOption = value;
                RaisePropertyChanged();
                OnOptionSelected(value);
            }
        }
        // Aplicar filtro al selecionar un archivo
        public string SelectedEvent
        {
            get => _selectedEvent;
            set
            {
                _selectedEvent = value;
                RaisePropertyChanged();
                ApplyEventFilter();
            }
        }
        // Cargar la vista previa al seleccionar un log o archivo
        public LogFileEventInfo SelectedLog
        {
            get => _selectedLog;
            set
            {
                _selectedLog = value;
                RaisePropertyChanged();
                LoadFilePreview();
            }
        }

        public string FilePreviewContent
        {
            get => _filePreviewContent;
            set { _filePreviewContent = value; RaisePropertyChanged(); }
        }

        public ConfigEntry SelectedConfig
        {
            get => _selectedConfig;
            set
            {
                _selectedConfig = value;
                RaisePropertyChanged();

                if (value != null)
                    LoadConfigDataAsync();
            }
        }

        // ----------------
        // COMANDOS
        // ----------------
        public ICommand BrowseCommand => _browseCommand;
        public ICommand FilterCommand { get; }

        // -----------------
        // CONSTRUCTOR
        // -----------------
        public MainVM(string name, IVMFactory vmFactory, IFileExplorerDialog fileExplorerDialog)
            : base(name)
        {
            _fileExplorerDialog = fileExplorerDialog;

            ComboOptions = new ObservableCollection<string> { "Archivos", "Carpetas" };
            SelectedOption = ComboOptions.First();

            _browseCommand = new DelegateCommand<string>(async path => await ExecuteBrowseAsync(path));
            FilterCommand = new DelegateCommand(async () => await FilterAsync());

            LoadSettings();

            // Configuración de la vista filtrada para el DataGrid
            FilteredEventsView = CollectionViewSource.GetDefaultView(LogFileEventCounts);
            FilteredEventsView.Filter = i => (i as LogFileEventInfo)?.IsVisible ?? true;
        }

        // ------------------------------
        // NAVEGACIÓN Y CARGA DE ARCHIVOS
        // ------------------------------
        private void OnOptionSelected(string option)
        {
            _browseCommand = new DelegateCommand<string>(async path => await ExecuteBrowseAsync(path));
            RaisePropertyChanged(nameof(BrowseCommand));
        }

        private async Task ExecuteBrowseAsync(string path)
        {
            string selected = null;

            if (SelectedOption == "Archivos")
                selected = _fileExplorerDialog.OpenFileDialog(path);
            else
                selected = _fileExplorerDialog.OpenDirectoryDialog(path);

            if (string.IsNullOrEmpty(selected))
                return;

            BrowsePath = selected;

            if (File.Exists(selected))
                await LoadSingleFileAsync(selected);
            else
                await Task.Run(() => LoadLogList(selected));

            SaveSettings();
        }

        private async Task LoadSingleFileAsync(string filePath)
        {
            LogFileEventCounts.Clear();

            if (!filePath.EndsWith(".grplog", StringComparison.OrdinalIgnoreCase))
                return;

            int count = await Task.Run(() => CountEventsInFile(filePath));

            LogFileEventCounts.Add(new LogFileEventInfo
            {
                NameLog = Path.GetFileName(filePath),
                FilePath = filePath,
                EventCount = count
            });

            UpdateDistinctEvents();
        }

        private void LoadLogList(string folder)
        {
            if (!Directory.Exists(folder))
                return;

            try
            {
                var logs = Directory.GetFiles(folder, "*.grplog")
                                  .Select(f => new LogFileEventInfo
                                  {
                                      NameLog = Path.GetFileName(f),
                                      FilePath = f,
                                      EventCount = CountEventsInFile(f)
                                  })
                                  .ToList();

                App.Current.Dispatcher.Invoke(() =>
                {
                    LogFileEventCounts.Clear();
                    foreach (var l in logs)
                        LogFileEventCounts.Add(l);

                    UpdateDistinctEvents();
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error loading folder: {ex.Message}");
            }
        }

        // Cargar automáticamente al escribir una ruta válida
        private async Task AutoLoadAsync()
        {
            if (string.IsNullOrWhiteSpace(BrowsePath))
                return;

            LogFileEventCounts.Clear();

            if (File.Exists(BrowsePath))
            {
                await LoadSingleFileAsync(BrowsePath);
            }
            else if (Directory.Exists(BrowsePath))
            {
                await Task.Run(() => LoadLogList(BrowsePath));
            }
        }



        // -----------------------------
        // FILTROS
        // -----------------------------
        private void ApplyEventFilter()
        {
            bool showAll = SelectedEvent == null || SelectedEvent == "Todos";

            foreach (var item in LogFileEventCounts)
                item.IsVisible = showAll || item.EventType == SelectedEvent;

            FilteredEventsView.Refresh();
        }

        private async Task FilterAsync()
        {
            if (string.IsNullOrEmpty(BrowsePath))
                return;

            string filePath = File.Exists(BrowsePath)
                ? BrowsePath
                : SelectedLog?.FilePath;

            if (filePath == null)
            {
                MessageBox.Show("Selecciona primero un archivo.", "Aviso");
                return;
            }

            var filtered = await Task.Run(() =>
                FilterLogByTime(filePath, StartTime, EndTime));

            LoadEventLines(filtered, filePath);

            UpdateDistinctEvents();
            SaveSettings();
        }

        private void LoadEventLines(IEnumerable<string> lines, string filePath)
        {
            App.Current.Dispatcher.Invoke(() =>
            {
                LogFileEventCounts.Clear();

                foreach (var line in lines)
                    LogFileEventCounts.Add(CreateEventLine(line, filePath));
            });
        }

        private LogFileEventInfo CreateEventLine(string line, string filePath)
        {
            return new LogFileEventInfo
            {
                NameLog = Path.GetFileName(filePath),
                FilePath = filePath,
                LineContent = line,
                EventCount = 1,
                EventType = DetectEventType(line)
            };
        }

        private IEnumerable<string> FilterLogByTime(string file, string start, string end)
        {
            var result = new List<string>();
            TimeSpan tStart = ParseTime(start);
            TimeSpan tEnd = ParseTime(end);

            foreach (var line in File.ReadLines(file))
            {
                var m = _timeRegex.Match(line);
                if (!m.Success) continue;

                var tValue = ParseTime(m.Groups[1].Value);
                if (tValue >= tStart && tValue <= tEnd)
                    result.Add(line);
            }

            return result;
        }

        // -----------------------
        // UTILIDADES Y AYUDAS
        // -----------------------
        private void LoadFilePreview()
        {
            if (SelectedLog == null || !File.Exists(SelectedLog.FilePath))
            {
                FilePreviewContent = string.Empty;
                return;
            }

            try
            {
                FilePreviewContent = File.ReadAllText(SelectedLog.FilePath);
            }
            catch
            {
                FilePreviewContent = "No se pudo leer el archivo.";
            }
        }

        private TimeSpan ParseTime(string s)
        {
            var p = s.Split(':');
            return p.Length == 4 &&
                   int.TryParse(p[0], out int h) &&
                   int.TryParse(p[1], out int m) &&
                   int.TryParse(p[2], out int s2) &&
                   int.TryParse(p[3], out int ms)
                ? new TimeSpan(0, h, m, s2, ms)
                : TimeSpan.Zero;
        }

        private int CountEventsInFile(string file)
        {
            int count = 0;

            try
            {
                foreach (var line in File.ReadLines(file))
                    if (_eventPattern.IsMatch(line))
                        count++;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error reading file: {ex.Message}");
            }

            return count;
        }

        private string DetectEventType(string line)
        {
            foreach (var key in _deepEvent)
                if (line.Contains(key, StringComparison.OrdinalIgnoreCase))
                    return key;

            var match = Regex.Match(line, @">>\s*(.*?)\s*changed", RegexOptions.IgnoreCase);
            return match.Success ? match.Groups[1].Value.Trim() : "Unknown";
        }

        // ---------------------------
        // HISTORIAL Y CONFIGURACIÓN
        // ---------------------------
        // Cargar historial desde archivo JSON
        private void LoadSettings()
        {
            try
            {
                if (!File.Exists(SettingsFile))
                    return;

                var json = File.ReadAllText(SettingsFile);
                var settings = JsonSerializer.Deserialize<AppSettingsVM>(json);

                if (settings?.History == null || !settings.History.Any())
                    return;

                ConfigHistory.Clear();
                foreach (var h in settings.History)
                    ConfigHistory.Add(h);

                var last = settings.History.Last();
                BrowsePath = last.LastFolder;
                StartTime = last.StartTime;
                EndTime = last.EndTime;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Settings load error: {ex.Message}");
            }
        }

        // Guardar nueva configuración en historial JSON
        private void SaveSettings()
        {
            try
            {
                var json = File.Exists(SettingsFile)
                    ? File.ReadAllText(SettingsFile)
                    : "{}";

                var settings = JsonSerializer.Deserialize<AppSettingsVM>(json) ?? new AppSettingsVM();

                var entry = new ConfigEntry
                {
                    LastFolder = BrowsePath,
                    StartTime = StartTime,
                    EndTime = EndTime
                };
                // Evitar duplicados
                if (!settings.History.Any(h =>
                    h.LastFolder == entry.LastFolder &&
                    h.StartTime == entry.StartTime &&
                    h.EndTime == entry.EndTime))
                {
                    settings.History.Add(entry);
                    // Limitar a 10 entradas de historial
                    if (settings.History.Count > 10)
                        settings.History.RemoveAt(0);
                }

                File.WriteAllText(SettingsFile,
                    JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Settings save error: {ex.Message}");
            }
        }
        // Cargar del comboBox la configuracion selecionada
        private async void LoadConfigDataAsync()
        {
            if (SelectedConfig == null)
                return;

            BrowsePath = SelectedConfig.LastFolder;
            StartTime = SelectedConfig.StartTime;
            EndTime = SelectedConfig.EndTime;

            LogFileEventCounts.Clear();

            if (File.Exists(BrowsePath))
                await LoadSingleFileAsync(BrowsePath);
            else if (Directory.Exists(BrowsePath))
                await Task.Run(() => LoadLogList(BrowsePath));

            await FilterAsync();
        }
        // Filtrado de eventos con distinct
        private void UpdateDistinctEvents()
        {
            var events = LogFileEventCounts
                .Select(x => x.EventType)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .OrderBy(x => x)
                .ToList();

            DistinctEvents.Clear();
            DistinctEvents.Add("Todos");

            foreach (var e in events)
                DistinctEvents.Add(e);

            SelectedEvent = "Todos";
        }
    }
}
