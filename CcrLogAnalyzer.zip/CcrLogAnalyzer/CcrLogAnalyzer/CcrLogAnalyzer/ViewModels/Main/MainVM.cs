﻿using System.Windows.Input;
using CcrLogAnalyzer.Factories;
using MVVM.Generic.Commands;
using MVVM.Generic.Services;
using MVVM.Generic.VM;

namespace CcrLogAnalyzer.ViewModels.Main
{
    public class MainVM : BaseViewModel
    {
        private BaseViewModel _topbarVM;
        private readonly IFileExplorerDialog _fileExplorerDialog;
        private ICommand _browseCommand;

        public BaseViewModel TopbarVM
        {
            get => _topbarVM;
            set { _topbarVM = value; RaisePropertyChanged(); }
        }

        public ICommand BrowseCommand { get; }

        private string _selectedComboOption;
        public string SelectedComboOption
        {
            get => _selectedComboOption;
            set
            {
                if (_selectedComboOption != value)
                {
                    _selectedComboOption = value;
                    RaisePropertyChanged();
                    OnComboSelectionChanged();
                }
            }
        }

        public MainVM(string name, IVMFactory vmFactory, IFileExplorerDialog fileExplorerDialog)
            : base(name)
        {
            _fileExplorerDialog = fileExplorerDialog;
            TopbarVM = vmFactory.GetTopbarVM();

            BrowseCommand = new DelegateCommand<string>(DoBrowse);

            SelectedComboOption = "Archivos"; 
        }

        private void DoBrowse(string path)
        {
            _fileExplorerDialog.OpenDirectoryDialog(path);
        }

        private void OnComboSelectionChanged()
        {
            var option = SelectedComboOption;

            _browseCommand = new DelegateCommand<string>(path =>
            {
                switch (option)
                {
                    case "Archivos":
                        _fileExplorerDialog.OpenFileDialog(path);
                        break;
                    case "Carpetas":
                        _fileExplorerDialog.OpenDirectoryDialog(path);
                        break;
                    case "Carpetas y Archivos":
                        _fileExplorerDialog.OpenFileDialog(path);
                        break;
                    default:
                        _fileExplorerDialog.OpenFileDialog(path);
                        break;
                }
            });  
        RaisePropertyChanged(nameof(BrowseCommand)); 
        }

    }
}
