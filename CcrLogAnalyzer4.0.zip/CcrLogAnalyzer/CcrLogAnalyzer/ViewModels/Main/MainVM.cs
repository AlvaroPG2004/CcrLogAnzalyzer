﻿using CcrLogAnalyzer.Factories;
using CcrLogAnalyzer.Models;
using CcrLogAnalyzer.ViewModels.Appsettings;
using MVVM.Generic.Commands;
using MVVM.Generic.Services;
using MVVM.Generic.VM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;


namespace CcrLogAnalyzer.ViewModels.Main
{
    public class LogFileEventInfo
    {
        public string NameLog { get; set; }
        public string FilePath { get; set; }
        public int EventCount { get; set; }
        public string LineContent { get; set; }

        public string EventType { get; set; }
    }

    public class MainVM : BaseViewModel
    {
        private readonly IFileExplorerDialog _fileExplorerDialog;
        private ICommand _browseCommand;
        public ICommand FilterCommand { get; }

        public ObservableCollection<string> ComboOptions { get; }
        private string _selectedOption;
        public string SelectedOption
        {
            get => _selectedOption;
            set
            {
                _selectedOption = value;
                RaisePropertyChanged();
                OnOptionSelected(value);
            }
        }
        private ConfigEntry _selectedConfig;

        public ConfigEntry SelectedConfig
        {
            get => _selectedConfig;
            set
            {
                _selectedConfig = value;
                if (value != null)
                {
                    //Actualizar los campos
                    BrowsePath = value.LastFolder;
                    StartTime = value.StartTime;
                    EndTime = value.EndTime;

                    //Refrescar los TextBox
                    RaisePropertyChanged(nameof(StartTime));
                    RaisePropertyChanged(nameof(EndTime));
                    RaisePropertyChanged(nameof(BrowsePath));

                    //Cargar el archivo o carpeta seleccionada
                    _ = LoadFromConfigAsync();
                }
                RaisePropertyChanged();
            }
        }
        //Recargar automáticamente el DataGrid al selecionar el historial
        private async Task LoadFromConfigAsync()
        {
            try
            {
                if (string.IsNullOrEmpty(BrowsePath))
                    return;

                LogFileEventCounts.Clear();

                //Si es archivo
                if (File.Exists(BrowsePath))
                {
                    await LoadSingleFileAsync(BrowsePath);
                }
                //Si es carpeta
                else if (Directory.Exists(BrowsePath))
                {
                    await Task.Run(() => LoadLogFilesAndCountEvents(BrowsePath));
                }

                //Aplicar filtro automáticamente
                await FilterAsync();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error cargando desde configuración: {ex.Message}");
            }
        }

        
        public ICommand BrowseCommand => _browseCommand;
        public ObservableCollection<LogFileEventInfo> LogFileEventCounts { get; set; } = new();

        private string _browsePath;
        public string BrowsePath
        {
            get => _browsePath;
            set { _browsePath = value; RaisePropertyChanged(); }
        }

        // Campos para filtrar por tiempo
        public string StartTime { get; set; } = "0:0:0:000";
        public string EndTime { get; set; } = "0:0:10:000";

        private readonly Regex _eventPattern = new(@"(ERROR|EVENT|WARN|REMOTE|LOCAL|TIME|0/0/0)", RegexOptions.IgnoreCase | RegexOptions.Compiled);
        private readonly Regex _timeRegex = new(@"^\d+/\d+/\d+\s+(\d+:\d+:\d+:\d+)", RegexOptions.Compiled);

        public MainVM(string name, IVMFactory vmFactory, IFileExplorerDialog fileExplorerDialog)
            : base(name)
        {
            _fileExplorerDialog = fileExplorerDialog;

            ComboOptions = new ObservableCollection<string>
            {
                "Archivos",
                "Carpetas"              
            };

            SelectedOption = ComboOptions.First();
            _browseCommand = new DelegateCommand<string>(async path => await ExecuteBrowseAsync(path));
            FilterCommand = new DelegateCommand(async () => await FilterAsync());
            LoadSettings();

        }

        private void OnOptionSelected(string option)
        {
            _browseCommand = new DelegateCommand<string>(async path => await ExecuteBrowseAsync(path));
            RaisePropertyChanged(nameof(BrowseCommand)); 
        }

        private async Task ExecuteBrowseAsync(string path)
        {
            switch (SelectedOption)
            {
                case "Archivos":
                    var filePath = _fileExplorerDialog.OpenFileDialog(path);
                    if (!string.IsNullOrEmpty(filePath))
                    {
                        BrowsePath = filePath;
                        await LoadSingleFileAsync(filePath);
                        SaveSettings();
                    }   
                    break;

                case "Carpetas":
                    var folderPath = _fileExplorerDialog.OpenDirectoryDialog(path);
                    if (!string.IsNullOrEmpty(folderPath))
                    {
                        BrowsePath = folderPath;
                        await Task.Run(() => LoadLogFilesAndCountEvents(folderPath));
                        SaveSettings();
                    }
                    break;
            }
        }

        private async Task LoadSingleFileAsync(string filePath)
        {
            LogFileEventCounts.Clear();

            if (!new[] { ".grplog" }.Contains(Path.GetExtension(filePath)?.ToLower()))
                return;

            int count = await Task.Run(() => CountEventsInFile(filePath));
            LogFileEventCounts.Add(new LogFileEventInfo
            {
                NameLog = Path.GetFileName(filePath),
                FilePath = filePath,
                EventCount = count
            });
        }
        
        private void LoadLogFilesAndCountEvents(string folderPath)
        {
            if (!Directory.Exists(folderPath))
                return;

            try
            {
                var logFiles = Directory.GetFiles(folderPath, "*.grplog", SearchOption.TopDirectoryOnly);
                var items = new List<LogFileEventInfo>();

                foreach (var filePath in logFiles)
                {
                    int count = CountEventsInFile(filePath);
                    items.Add(new LogFileEventInfo
                    {
                        NameLog = Path.GetFileName(filePath),
                        FilePath = filePath,
                        EventCount = count
                    });
                }

                App.Current.Dispatcher.Invoke(() =>
                {
                    LogFileEventCounts.Clear();
                    foreach (var item in items)
                        LogFileEventCounts.Add(item);
                });
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error accediendo a la carpeta: {ex.Message}");               
            }
        }

        private int CountEventsInFile(string filePath)
        {
            int count = 0;
            try
            {
                foreach (var line in File.ReadLines(filePath))
                 {
                    if (_eventPattern.IsMatch(line))
                    {
                        string eventType = DetectEventType(line);
                        count++;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error leyendo archivo {filePath}: {ex.Message}");
            }
            return count; 
        }        
        
        private async Task FilterAsync()
        {
            if (string.IsNullOrEmpty(BrowsePath))
                return;
           
            string filePath = BrowsePath;
            if (Directory.Exists(BrowsePath))
            {
                
                filePath = Directory.GetFiles(BrowsePath, "*.grplog").FirstOrDefault();
            }
            
            if (filePath == null || !File.Exists(filePath))
                return;
            
            var filteredLines = await Task.Run(() => FilterLogByTime(filePath, StartTime, EndTime));

            App.Current.Dispatcher.Invoke(() =>
            {
                LogFileEventCounts.Clear();
                foreach (var line in filteredLines)
                {
                    LogFileEventCounts.Add(new LogFileEventInfo
                    {
                        NameLog = Path.GetFileName(filePath),
                        FilePath = filePath,
                        LineContent = line,
                        EventCount = 1,
                        EventType = DetectEventType(line)
                    });
                }
            });
            SaveSettings();
        }
        
        private IEnumerable<string> FilterLogByTime(string filePath, string startTime, string endTime)
        {
            var result = new List<string>();
            TimeSpan start = ParseTime(startTime);
            TimeSpan end = ParseTime(endTime);

            foreach (var line in File.ReadLines(filePath))
            {
                var match = _timeRegex.Match(line);
                if (match.Success)
                {
                    var timeValue = ParseTime(match.Groups[1].Value);
                    if (timeValue >= start && timeValue <= end)
                        result.Add(line);
                }
            }
            return result;
        }

        private TimeSpan ParseTime(string time)
        {
            var parts = time.Split(':');
            if (parts.Length == 4 &&
                int.TryParse(parts[0], out int h) &&
                int.TryParse(parts[1], out int m) &&
                int.TryParse(parts[2], out int s) &&
                int.TryParse(parts[3], out int ms))
            {
                return new TimeSpan(0, h, m, s, ms);
                
            }
            return TimeSpan.Zero;
        }

        private LogFileEventInfo _selectedLog;
        public LogFileEventInfo SelectedLog
        {
            get => _selectedLog;
            set 
            {
                _selectedLog = value;
                RaisePropertyChanged();               
            } 
        }
        private const string SettingsFile = "settings.json";

        public ObservableCollection<ConfigEntry> ConfigHistory { get; set; } = new();

        private void LoadSettings()
        {
            try
            {
                if (File.Exists(SettingsFile))
                {
                    var json = File.ReadAllText(SettingsFile);
                    var settings = JsonSerializer.Deserialize<AppSettingsVM>(json);

                    if (settings != null && settings.History.Any())
                    {
                     
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            ConfigHistory.Clear();
                            foreach (var item in settings.History)
                                ConfigHistory.Add(item);
                        });

                        //Cargar la última configuración
                        var last = settings.History.Last();
                        BrowsePath = last.LastFolder ?? string.Empty;
                        StartTime = last.StartTime ?? "0:0:0:000";
                        EndTime = last.EndTime ?? "0:0:10:000";
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error al cargar configuración: {ex.Message}");
            }
        }


        private void SaveSettings()
        {
            try
            {
                AppSettingsVM settings;

                if (File.Exists(SettingsFile))
                {
                    var json = File.ReadAllText(SettingsFile);
                    settings = JsonSerializer.Deserialize<AppSettingsVM>(json) ?? new AppSettingsVM();
                }
                else
                {
                    settings = new AppSettingsVM();
                }

                // Crear la nueva entrada actual
                var newEntry = new ConfigEntry
                {
                    LastFolder = BrowsePath,
                    StartTime = StartTime,
                    EndTime = EndTime
                };

                // Evitar duplicados consecutivos
                if (!settings.History.Any(h =>
                    h.LastFolder == newEntry.LastFolder &&
                    h.StartTime == newEntry.StartTime &&
                    h.EndTime == newEntry.EndTime))
                {
                    settings.History.Add(newEntry);

                    // Limitar a las últimas 15 configuraciones
                    if (settings.History.Count > 15)
                        settings.History.RemoveAt(0);
                }

                var newJson = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsFile, newJson);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error al guardar configuración: {ex.Message}");
            }
        }

        private readonly List<string> _deepEvent = new List<string>
             {
    "Previous Local",
    "Power Loss",
    "STEP",
    "Sensor",
    "REMOTE",
    "Save config",
    "CCR",
    "Voltage",
    "Temperature",
    "HoroMeter",
    "Hours",
    "Minutes"
             };

        private string DetectEventType(string line)
        {
            foreach (var pattern in _deepEvent)
            {
                if (line.Contains(pattern, StringComparison.OrdinalIgnoreCase))
                    return pattern;
            }

            // Si no encaja, detectamos la parte entre ">>" y "changed"
            var match = Regex.Match(line, @">>\s*(.*?)\s*changed", RegexOptions.IgnoreCase);
            if (match.Success)
                return match.Groups[1].Value.Trim();

            return "Unknown";
        }

    }
}