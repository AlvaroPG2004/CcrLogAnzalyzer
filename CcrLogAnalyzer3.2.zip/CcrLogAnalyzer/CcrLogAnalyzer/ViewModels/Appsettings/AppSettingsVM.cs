﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CcrLogAnalyzer.ViewModels.Appsettings
{
    public class AppSettingsVM
    {
        public string LastFolder { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
    }
}
