﻿using MVVM.Generic.VM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CcrLogAnalyzer.ViewModels.Topbar
{
    public class TopbarVM : BaseViewModel
    {
        public TopbarVM(string name) : base(name)
        {
        }
    }
}
