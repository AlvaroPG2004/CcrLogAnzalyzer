﻿using CcrLogAnalyzer.Factories;
using MVVM.Generic.Commands;
using MVVM.Generic.Services;
using MVVM.Generic.VM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;

namespace CcrLogAnalyzer.ViewModels.Main
{  
    public class LogFileEventInfo
    {
        public string NameLog { get; set; }
        public string FilePath { get; set; }
        public int EventCount { get; set; }
    }

    public class MainVM : BaseViewModel
    {
        private readonly IFileExplorerDialog _fileExplorerDialog;
        private ICommand _browseCommand;

        public ObservableCollection<string> ComboOptions { get; }

        private string _selectedOption;
        public string SelectedOption
        {
            get => _selectedOption;
            set
            {
                _selectedOption = value;
                RaisePropertyChanged();
                OnOptionSelected(value);
            }
        }

        public ICommand BrowseCommand => _browseCommand;

        public BaseViewModel TopbarVM { get; set; }

        private string _browsePath;
        public string BrowsePath
        {
            get => _browsePath;
            set { _browsePath = value; RaisePropertyChanged(); }
        }

        public ObservableCollection<LogFileEventInfo> LogFileEventCounts { get; set; } = new();

        private readonly string[] _eventKeywords = new[] { "ERROR", "EVENT", "WARN", "REMOTE", "LOCAL" ,"TIME", "0/0/0"};

        public MainVM(string name, IVMFactory vmFactory, IFileExplorerDialog fileExplorerDialog)
            : base(name)
        {
            _fileExplorerDialog = fileExplorerDialog;
            TopbarVM = vmFactory.GetTopbarVM();

            ComboOptions = new ObservableCollection<string>
        {
            "Archivos",
            "Carpetas",
            "Carpetas y Archivos"
        };

            SelectedOption = ComboOptions.FirstOrDefault();

            
            _browseCommand = new DelegateCommand<string>(async path => await ExecuteBrowseAsync(path));
        }

        private void OnOptionSelected(string option) 
        {  
            
            _browseCommand = new DelegateCommand<string>(async path => await ExecuteBrowseAsync(path));
            RaisePropertyChanged(nameof(BrowseCommand));
        }
        
        private async Task ExecuteBrowseAsync(string path)
        {
            switch (SelectedOption)
            {
                case "Archivos":
                    var filePath = _fileExplorerDialog.OpenFileDialog(path);
                    if (!string.IsNullOrEmpty(filePath))
                    {
                        BrowsePath = Path.GetDirectoryName(filePath);
                        await LoadSingleFileAsync(filePath);
                    }
                    break;

                case "Carpetas":
                    var folderPath = _fileExplorerDialog.OpenDirectoryDialog(path);
                    if (!string.IsNullOrEmpty(folderPath))
                    {
                        BrowsePath = folderPath;
                        await Task.Run(() => LoadLogFilesAndCountEvents(folderPath));
                    }
                    break;

                case "Carpetas y Archivos":
                    var mixedPath = _fileExplorerDialog.OpenFileDialog(path);
                    if (!string.IsNullOrEmpty(mixedPath))
                    {
                        BrowsePath = mixedPath;
                        await Task.Run(() => LoadLogFilesAndCountEvents(mixedPath, recursive: true));
                    }
                    break;
                    
                default:
                    break;
            }
        }

        private async Task LoadSingleFileAsync(string filePath)
        {
            LogFileEventCounts.Clear();

            if (Path.GetExtension(filePath)?.ToLower() != ".grplog")
                return;

            int count = await Task.Run(() => CountEventsInFile(filePath));
            LogFileEventCounts.Add(new LogFileEventInfo
            {
                NameLog = Path.GetFileName(filePath),
                FilePath = filePath,
                EventCount = count
            });
        }

        private void LoadLogFilesAndCountEvents(string folderPath, bool recursive = false)
        {
            

            if (!Directory.Exists(folderPath))
                return;

            try
            {
                var logFiles = Directory.GetFiles(folderPath, "*.grplog",
                    recursive ? SearchOption.AllDirectories : SearchOption.TopDirectoryOnly);
                

                var items = new List<LogFileEventInfo>();

                foreach (var filePath in logFiles)
                {
                    int count = CountEventsInFile(filePath);
                    items.Add(new LogFileEventInfo
                    {
                        NameLog = Path.GetFileName(filePath),
                        FilePath = filePath,
                        EventCount = count
                    });
                }
             
                App.Current.Dispatcher.Invoke(() =>
                {
                    LogFileEventCounts.Clear();
                    foreach (var item in items)
                        LogFileEventCounts.Add(item); 
                });

            }

            catch (Exception ex)
            {
                Debug.WriteLine($"Error accediendo a la carpeta: {ex.Message}");
            }
        }

        private int CountEventsInFile(string filePath)
        {
            int count = 0;
            
            try
            {
                foreach (var line in File.ReadLines(filePath))
                {
                    if (_eventKeywords.Any(k => line.Contains(k, StringComparison.OrdinalIgnoreCase)))
                    {
                       count++;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error leyendo archivo {filePath}: {ex.Message}");
            }

            return count;
        }
    }
}