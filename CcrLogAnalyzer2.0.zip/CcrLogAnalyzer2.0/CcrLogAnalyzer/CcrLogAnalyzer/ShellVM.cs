﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MVVM.Generic.VM;

namespace CcrLogAnalyzer
{
    public class ShellVM : BaseViewModel
    {
        public ShellVM(string name) : base(name)
        {
        }
    }
}
